# advmemtest — UEFI Shell 内存压测工具

![全功能演示](docs/manual/images/feature-tour.gif)

advmemtest 是一款运行在 **UEFI Shell** 下的图形化内存压力测试工具，对标 Memtest86 系列，以 **Free / Pro 双版本**发行（免费版个人免费使用；专业版商业用途需授权）。单文件 efi 无外部依赖，全简体中文界面，鼠标 + 键盘双路操作，面向服务器、工作站的**装机验收、故障排查与返修质检**。

> 本项目为私有仓库，不对外开放源码。

> **当前版本 0.1.7**（BUILD 562，Free / Pro 双产物）——二进制与说明书见 [Releases](https://github.com/MikeWuPing/advmemtest/releases/latest)。

---

## 主要功能（配图）

### 颗粒级错误定位（Pro 版）

错误地址换算为 **Socket/Channel/DIMM/Rank/Device 五级坐标**——直接指出"哪根内存条上的哪个颗粒坏了"。错误三通道同时呈现：UI 错误日志、DIMM 带颗粒红光晕、徽章转 FAIL。Free 版错误只到地址（定位信息源头不产生，非"算出来不显示"）。

![错误注入演示](docs/manual/images/s09-inject.png)

### 自我重定位（独家）

启动时把自身镜像搬移到新地址、释放原区域——**把自己占用的内存也纳入测试**，覆盖不留死角。主流内存测试工具都测不到自己占的内存。

### 多核真实并发

单线程之外提供三条多核模式：**多线程**（内存按核切段、并行压测，4 核实测吞吐约 2.5×）、**顺序轮巡**（每核全量轮流）、**轮流**（pattern 与核心对轮转）。MP Services 真实调度，多核缺席自动降级并注明；Free 版上限 16 核、Pro 版按系统核数实探（上限 512 核）。

![多线程运行](docs/manual/images/s10-multithread.png)

### 33 条测试 Pattern 全真实实现（Free 15 / Pro 33）

地址测试 / memtest86+ 系（移动反转、块移动、随机、Modulo 20、Bit fade）/ **AMT 系 12 条**（产品名 Adv 前缀：MATS8、XMATS、WCMATS、WCMCH、GNDB、MARCHCM、TWR、DATA_RET、SCRAM_X2）/ **通用行锤**（两版都有）/ **厂商系 3 条**（海力士、三星、美光原厂算法，按 SPD 厂商自动门控）/ 增补条 2 条（XMATS32/64）/ **SIMD 宽访存 2 条**（SIMD-128 走 SSE2 基线，两版都有；SIMD-256 走 AVX2，需固件启用 AVX——多数 edk2 系固件未开时该条自动锁定，不影响其它条）。Pro 域 18 条在 Free 版中灰显锁定。

![Pattern 选择（Free 版锁定行）](docs/manual/images/s26-free-locked.png)

### HTML 报告落盘 + 坏块清单（Pro）

停止测试、跑满指定轮数或退出时自动写 `fs0:\advmemtest_report.html`：汇总统计、错误明细（Pro 含颗粒定位）、DIMM 布局可视化，浏览器直接打开，适合存档与随返修件流转。Pro 版同时导出 `badram.txt`（Linux BadRAM 格式）与 `badmemorylist.txt`（Windows bcdedit 命令）。

![HTML 报告](docs/manual/images/s15b-report-err.png)

### 颗粒几何真值化（0.1.7 新）

内存条上到底有几颗颗粒，只有 **SPD** 知道——SMBIOS 与 ACPI 规范里都没有"器件位宽"这个字段（x4/x8/x16）。所以本工具不装懂：**拿得到真值就显示真值，拿不到就显式标注"推测"**。

颗粒数由几何模型算出（`数据颗粒 = 64/位宽`、`ECC 颗粒 = ECC?8/位宽:0`、`RCD = Registered?1:0`），输入取自 SMBIOS 里真实存在的字段（形态 / Registered / ECC 位 / rank 数）。悬停内存条即可看到：

![悬停浮层：容量、器件位宽（标注推测）、颗粒数](docs/manual/images/s13-tip-dimm.png)

> 背景：此前版本的"每根条都显示 x4 / 16 颗"是写死在代码里的假值，0.1.7 已修——SODIMM 现在按真实几何显示 8 颗而非 16 颗。器件位宽的 SPD 真值通路属 Pro 版后续版本。

### 动态 DIMM 可视化带

SMBIOS 双入口（Type 16 槽总数 / Type 17 已插几何）驱动，槽位随平台动态变化——最大 48 槽、空槽置灰（EMPTY）、双路平台分组头（CPU0/CPU1），颗粒按真实几何渲染（数据颗粒 + ECC 颗粒 + RCD 缓冲），活动槽光晕流动，悬停弹 tooltip（插槽名/容量/组织/颗粒数）。

![多 DIMM 槽（16 槽双组）](docs/manual/images/s18-dimms-groups.png)

### 现代界面与交互（0.1.7 新）

基于新代图形库：**磨砂玻璃卡片**（圆角 + 半透明 + 背景模糊）、**深浅双主题**（设置 →"外观..."即时切换并持久化到 `ADVMTEST.CFG`）、对话框与主界面**转场动画**、列表**鼠标滚轮**滚动。固件不带可用指针设备时，应用内嵌 USB HID boot mouse 驱动接管——没有鼠标驱动的机器照样能用鼠标。

交互细节：未开始测试时"停止测试"灰显不可点；**运行中/暂停中禁止修改测试参数**（Pattern、线程模式、测试配置——菜单项、模式面包屑、轮次卡三处入口一并封锁，避免"改了当前这轮"的误解）；"帮助"菜单新增"退出"（走退出确认，不直接退）。

### Pro 版能力补充

SPD 深度内存信息页（六后端采集 + SMBIOS 摘要降级态，含**内存温度明细**与 **ECC 明细**）、内存带宽曲线（工作集扫描，读/写/拷贝三线 + SIMD 对照线 + L1/L2/L3/内存四档缓存台阶标注）、禁用缓存模式（CR0.CD 旁路，暴露被缓存掩盖的故障）、内存健康卡（**两版都有**；温度当前/峰值 + ECC CE/UE，读不到的项目与卡片自动隐藏）——**专业版多出温度面**，**免费版只可能亮 ECC 一面**（不编 SPD 栈，温度源由构造不存在）、平台坐标协议契约（固件侧"物理地址 → 颗粒"精确解析接口，Pro 与硬件绑定——**契约先行、消费链列后续版本**）。

**两版通用的新界面元素**：底部**平台信息条**——`CPU · 主板 · 内存总量`，右端为 `起测 14:32 · 已测 1:23`（两段都带标签；未开始显示 `—`；时长不含暂停，停止后冻结；起测时刻取固件墙钟，不保证等于墙上时钟）。

## 版本与授权

| | 免费版（AdvMemTestFree.efi） | 专业版（AdvMemTestPro.efi） |
|---|---|---|
| 可执行 Pattern | 15 条可执行（13 条用户可见 + 2 条引擎自检参考条） | 33 条可执行（31 条目录；Pro 独有 +18：AMT 系/厂商系/增补条/SIMD-256 宽访存——行锤与 SIMD-128 两版都有） |
| 错误定位 | 只到地址 | 颗粒级五级坐标（对标 Memtest86 Pro Site 级）+ DIMM 带/报告红标 |
| 多核 | 上限 16 核 | MP 实探，上限 512 核 |
| SPD 深度页 | —（SMBIOS tooltip 摘要） | 内存信息…全屏 SPD 解码页 |
| 内存健康卡 | ECC CE/UE（温度源不存在） | 温度 + ECC |
| 带宽曲线 | 读取一条线 | 读/写/拷贝 + SIMD 对照 + 缓存台阶标注 |
| 禁用缓存模式 | — | CR0.CD 旁路测试 |
| 坏块清单导出 | — | badram / badmemorylist |
| 授权条款 | **个人用户免费使用** | **商业用途（营利性部署/分发/预装）需授权** |

Pro 版启动时校验同目录授权文件 `ADVMTEST.LIC`（RSA-2048 离线验签，四种授权形态：客户级/绑机 × 长期/期限）；无证、坏证、超期、机器不匹配均拒绝启动并提示原因。**升级途径：Pro 版授权请联系作者**（详见 `docs/manual/user-guide-pro.md` 第七章"授权与安装"）。

## 快速开始

**方式一：可直启 ISO（不需要 UEFI Shell）**——`dist/advmemtest-free.iso` / `dist/advmemtest-pro.iso`（由 `tools/New-BootIso.ps1` 生成）：刻到 U 盘（Rufus / balenaEtcher / Ventoy / `dd`），或挂到 BMC 虚拟光驱，开机直接从该设备启动即进入程序；Ventoy 菜单第一项"正常模式"即可，"grub2 模式"也能启动——ISO 内嵌 `/EFI/BOOT/grub.cfg` 兜底（Ventoy 把 ISO 挂成 `(loop)` 后由 GRUB chainload 盘内 efi）。2026-09-18 于 Ventoy 1.1.17 实测：免费版两种模式均启动；**专业版请走正常模式**——grub2 链路下 GRUB 交棒时不暴露程序目录，`ADVMTEST.LIC` 定位不到会拒绝启动（该模式下的兜底是"把证放到可读盘的根目录"，**真机未实测**；正常模式不受影响）。**grub2 链路下 `ADVMTEST.CFG` 同样不可达**（设置读不到也存不下）。上述 ISO 内嵌兜底只在 Ventoy 1.1.17 上实测过，其它版本未逐一验证；本程序为纯 UEFI 结构，不支持 BIOS/CSM。实测（OVMF 直启光驱，无磁盘、无 Shell、无 `startup.nsh`）：串口 `APP_VERSION=` 与界面右下角版本水印一致；Pro 版从 ISO 内的 `EFI/BOOT/ADVMTEST.LIC`（dev 测试授权，长期有效、不绑机，供功能评估；商业部署请换正式授权）放行。
三条实测口径：① **先关 Secure Boot**（程序未签名）；② 介质只读时**报告与坏块清单仍能落盘**——程序会写到**第一个可写卷的根**（Ventoy 上即 VTOYEFI 分区根；dd 直写的盘内 ESP 空簇亦可）；**只有设置（`ADVMTEST.CFG`）恒存不下来**，要两者都稳就把 `efi` 拷到**可写 FAT32 盘**跑（启动形态 × 能否存盘对照表见 `docs/manual/user-guide-free.md` 1.2）；整机没有可写卷时串口才打 `WARN: report write failed: Write Protected`，不崩、测试不受影响；③ 程序"退出"后回到固件引导流程（OVMF 实测落在启动设备选择菜单，未自动重引导本盘；若你的机器启动顺序里该盘仍列首位，可能重新引导），离开测试请断电、改启动顺序或拔盘。

**方式二：UEFI Shell**：

1. 将版本对应的 efi 复制到 UEFI Shell 所在盘（如 `fs0:`）——`AdvMemTestFree.efi` 或 `AdvMemTestPro.efi`（Pro 版须与授权文件 `ADVMTEST.LIC` 同目录）；
2. Shell 下输入文件名回车（或写入 `startup.nsh` 开机自启）；
3. **连按两下回车**起测（多核机器自动全核并行）；
4. 运行中按 `Esc` 暂停（再按继续；停止走菜单"停止测试"），空闲按 `Esc` 弹出退出确认，也可以走菜单 帮助 → 退出；
5. 报告自动写到 `fs0:\advmemtest_report.html`（Pro 版另有 `badram.txt` / `badmemorylist.txt`）。

详细用法见 `docs/manual/user-guide-free.md`（免费版技术手册）、`docs/manual/user-guide-pro.md`（专业版技术手册）与 `docs/manual/quick-guide.md`（简版快速上手）。

## 构建

```powershell
# 依赖：edk2 + LvglPkg + VS2019（LvglPkg 取新代：UEFI_Tools 仓库的 LvglPkg/ 目录，
#       git clone https://github.com/MikeWuPing/UEFI_Tools 后把其中的 LvglPkg 放到项目根）
powershell -ExecutionPolicy Bypass -File tools/Build-AdvMemTest.ps1
powershell -ExecutionPolicy Bypass -File tools/Run-AdvMemTestQemu.ps1   # QEMU 验证
powershell -ExecutionPolicy Bypass -File tools/Pack-ReleaseSku.ps1 -Sku All   # 发布装配（dist/release/*.zip）
#   Free 产物 AdvMemTest-<ver>.<build>+<stamp>.zip ／ Pro 产物 AdvMemTest-pro-…zip；
#   带版本闸门（expected_version 必须与本 BUILD 一致）与打包后自检。
#   旧入口 tools/Package-Release.ps1 已停用（脚本首行起 throw "OBSOLETE"，P27）。
```

## 目录结构

```
AdvMemTestPkg/Application/AdvMemTest/
  Core/      应用入口与生命周期（含自我重定位）
  Ui/        LVGL 界面（菜单/对话框/仪表盘/DIMM 可视化）
  Test/      测试引擎（33 条 pattern/多核调度/错误映射/自检/报告/坏块导出）
  Platform/  平台层（SMBIOS/MP Services/SMBus/License/SPD 总线适配）
  Verbatim/  照搬的 SPD 解码栈（Pro 编入，Free 空翻译单元）
docs/
  manual/    产品说明书（简版 / 免费版详版 / 专业版详版，可转 Word）+ 功能截图 + 演示 GIF
  board-porting-guide.md  上板对接手册
  advmemtest-platform-map-protocol.md  平台坐标协议契约（Pro 与硬件绑定）
tools/       构建/验证/发布脚本
```

## 上板（真机）

QEMU 闭环验证全部功能；真机对接按 `docs/board-porting-guide.md` 的复测清单执行（MRC 交错表、SMBus SPD、厂商白名单、Ventoy 真盘两模式、MSR #GP 接住证据等）。

---

# advmemtest — UEFI Shell Memory Stress Test Tool (English)

A GUI memory stress-test tool running in **UEFI Shell**, benchmarked against the Memtest86 family, released as **Free / Pro editions** (Free: free for personal use; Pro: commercial use requires a license). Single-file EFI with no external dependencies, full Simplified-Chinese UI, mouse + keyboard, built for **server/workstation acceptance, fault diagnosis, and RMA quality inspection**.

> Private repository — source code is not open-sourced.

> **Current version 0.1.7** (BUILD 562, Free / Pro) — binaries and manuals are on the [Releases](https://github.com/MikeWuPing/advmemtest/releases/latest) page.

## Feature Highlights

- **Chip-level error location (Pro)**: error addresses are mapped to **Socket/Channel/DIMM/Rank/Device** coordinates — pinpoints *which chip on which DIMM* failed. Errors surface through three channels simultaneously: on-screen error log, DIMM-strip red glow, and FAIL badge. Free edition reports addresses only (location fields are never even produced — not merely hidden).
- **Self-relocation (unique)**: the app relocates its own image at startup and releases its original region — *memory occupied by the tool itself is also tested*.
- **True multi-core concurrency**: Multi-thread (address-split parallel, ~2.5× throughput measured on 4 vCPUs), Sequential (per-core full sweep), and Round-Robin (pattern×core rotation) modes on top of single-thread; automatic single-core fallback with status note; Free caps at 16 cores, Pro probes the system (up to 512).
- **33 real test patterns (15 Free / 33 Pro)**: address tests / memtest86+ family (moving inversions, block move, random, modulo-20, bit fade) / **row hammer (both editions)** / **12 AMT patterns** (product names use the "Adv " prefix: MATS8, XMATS, WCMATS, WCMCH, GNDB, MARCHCM, TWR, DATA_RET, SCRAM_X2) / **3 vendor patterns** (SK hynix, Samsung, Micron algorithms, SPD vendor gated) / 2 augmented patterns (XMATS32/64) / **2 SIMD wide-access patterns** (SIMD-128 uses baseline SSE2, in both editions; SIMD-256 needs AVX2 enabled by the firmware — most edk2-based firmware leaves it off, in which case that single pattern locks itself out without affecting any other entry). The 19 Pro-domain entries appear greyed-out and locked in the Free edition.
- **HTML report on disk + bad-block export (Pro)**: written automatically on stop / pass-limit reached / exit to `fs0:\advmemtest_report.html` — summary, error details (with chip location in Pro), DIMM layout visualization; Pro also exports `badram.txt` (Linux BadRAM format) and `badmemorylist.txt` (Windows bcdedit command).
- **Dynamic DIMM visual strip**: SMBIOS dual-entry (Type 16 total slots / Type 17 populated) — up to 48 slots, empty slots greyed ("EMPTY"), group headers on dual-socket platforms, chips rendered from the module's real geometry (data chips + ECC dies + RCD), activity glow, hover tooltips.
- **True chip geometry (new in 0.1.7)**: the chip count is computed from the module's real geometry (`data = 64 / device-width`, plus `ECC ? 8/device-width : 0` dies and one RCD where registered), driven by SMBIOS fields that actually exist (form factor, registered, ECC, ranks). Device width (x4/x8/x16) exists **only in SPD** — no SMBIOS or ACPI table carries it — so when the tool cannot obtain it, it says so instead of guessing: the hover tooltip reads `x8（推测）` ("assumed") and the serial locator reads `dev0(approx)`. Earlier builds hard-coded "x4 / 16 chips" for every module; that fabrication is gone.
- **Modern UI & interaction (new in 0.1.7)**: frosted-glass cards, dark/light themes (Settings → Appearance, persisted to `ADVMTEST.CFG`), dialog and entrance transitions, mouse-wheel scrolling, and an embedded USB HID boot-mouse fallback for firmware with no usable pointer device. "Stop test" is greyed out until a run starts; test parameters (patterns, thread mode, test config) cannot be changed while running or paused — all three entry points (menu, breadcrumb, stat card) are guarded — and Help → Exit opens the usual quit confirmation.
- **Additional Pro capabilities**: SPD deep memory-info page (six backends + SMBIOS-summary fallback, with **per-module temperature** and **per-bank ECC** detail), memory bandwidth curve (working-set sweep: read/write/copy + a SIMD reference line, with L1/L2/L3/memory cache-tier markers), cache-bypass test mode (CR0.CD), the memory-health card (**present in both editions**; temperature current/peak + ECC CE/UE; unreadable fields and the card itself hide automatically) — **the temperature face is Pro-only**; **the Free edition can only ever light its ECC face** (no SPD stack is compiled in, so no temperature source exists), and the platform-map protocol contract (BIOS-provided physical-address → chip resolution, Pro binds to the hardware).
- **New in both editions**: a bottom platform info bar — `CPU · board · memory total`, with `start time / elapsed` on the right (shows `—` before a run; elapsed excludes paused time and freezes when the test stops).

## Edition & Licensing

| | Free (AdvMemTestFree.efi) | Pro (AdvMemTestPro.efi) |
|---|---|---|
| Executable patterns | 15 executable (13 visible + 2 engine self-check reference entries) | 33 executable (31 listed; Pro-only +18: AMT / vendor / augmented / SIMD-256 — row hammer and SIMD-128 ship in both) |
| Error location | Address only | Chip-level 5-axis (Memtest86 Pro Site-class) + DIMM/report red marks |
| Multi-core | 16-core cap | MP-probed, up to 512 |
| SPD deep page | — (SMBIOS tooltip summary) | Full-screen SPD decode page |
| Memory health card | ECC CE/UE (no temperature source) | Temperature + ECC |
| Bandwidth curve | Read only | Read/write/copy + SIMD reference + cache-tier markers |
| Cache-bypass mode | — | CR0.CD bypass |
| Bad-block export | — | badram / badmemorylist |
| Licensing | **Free for personal use** | **Commercial use requires a license** |

Pro edition verifies the `ADVMTEST.LIC` file next to the binary at startup (offline RSA-2048 signature, four license shapes: customer/machine-bound × lifetime/term); missing, invalid, expired or machine-mismatched licenses reject startup with a readable reason. **To upgrade to Pro, please contact the author** (see chapter 7 "Licensing & Installation" in `docs/manual/user-guide-pro.md`).

## Quick Start

**Option 1 — bootable ISO (no UEFI Shell needed)**: `dist/advmemtest-free.iso` / `dist/advmemtest-pro.iso` (built by `tools/New-BootIso.ps1`). Write it to a USB stick (Rufus / balenaEtcher / Ventoy / `dd`) or mount it as a BMC virtual CD, then boot that device — the program comes up directly; on Ventoy pick the FIRST menu entry (normal mode); the "grub2 mode" entry boots as well (the ISO carries an `/EFI/BOOT/grub.cfg` fallback that chainloads the on-disc binary once Ventoy has mounted the ISO as `(loop)`). Measured on Ventoy 1.1.17, 2026-09-18: the Free disc boots in both modes; **use normal mode with the Pro disc** - on the GRUB hand-off the program folder is not exposed, so `ADVMTEST.LIC` cannot be located and the program refuses to run (the fallback there is "put the license at the root of a readable disk", **not yet measured on real hardware**; normal mode is unaffected). **In grub2 mode `ADVMTEST.CFG` is unreachable too** (settings cannot be read or saved). The ISO-embedded fallback was measured on Ventoy 1.1.17 only; other versions were not verified one by one. The boot structure is pure UEFI - no BIOS/CSM. Measured on OVMF booting the CD directly (no disk, no Shell, no `startup.nsh`): the serial `APP_VERSION=` matches the version watermark in the UI, and the Pro edition licenses itself from `EFI/BOOT/ADVMTEST.LIC` inside the ISO (a dev evaluation license: long-lived, not machine-bound; use a real license for commercial deployment).
Three measured facts: (1) **disable Secure Boot** (the binary is unsigned); (2) on read-only media the **report and bad-block lists still land** — the tool writes them to the **root of the first writable volume** (on Ventoy that is the VTOYEFI partition root; an empty cluster of the on-disc ESP works for dd-written media); **only settings (`ADVMTEST.CFG`) can never be saved**; for both, copy the `efi` onto a **writable FAT32 drive** (see the boot-media × writability table in `docs/manual/user-guide-free.md` §1.2); the serial shows `WARN: report write failed: Write Protected` only when no writable volume exists at all, and nothing crashes, the test is unaffected; (3) "Exit" returns to the firmware boot flow (measured on OVMF: it dropped into the boot-device selection menu, it did **not** immediately re-boot this disc — but if your boot order still lists the disc first, it may loop back), so power off, change the boot order or remove the media to leave.

**Option 2 — UEFI Shell**:

1. Copy the matching binary to your UEFI Shell drive (e.g. `fs0:`) — `AdvMemTestFree.efi` or `AdvMemTestPro.efi` (Pro also needs `ADVMTEST.LIC` alongside);
2. Run it in the Shell (or add to `startup.nsh`);
3. **Press Enter twice** to start (multi-core machines parallelize automatically);
4. `Esc` pauses a running test (press again to resume; stop via the menu); `Esc` while idle — or Help → Exit — opens the quit confirmation;
5. The report is written to `fs0:\advmemtest_report.html` (Pro adds `badram.txt` / `badmemorylist.txt`).

Full documentation: `docs/manual/user-guide-free.md` (Free edition), `docs/manual/user-guide-pro.md` (Pro edition) and `docs/manual/quick-guide.md` (quick start), also available as Word documents.

## Build

```powershell
powershell -ExecutionPolicy Bypass -File tools/Build-AdvMemTest.ps1      # build
powershell -ExecutionPolicy Bypass -File tools/Run-AdvMemTestQemu.ps1   # QEMU verify
powershell -ExecutionPolicy Bypass -File tools/Pack-ReleaseSku.ps1 -Sku All   # assemble release zips (dist/release/*.zip)
#   Free -> AdvMemTest-<ver>.<build>+<stamp>.zip ; Pro -> AdvMemTest-pro-...zip ;
#   version-gated (expected_version must match this BUILD) + post-zip self-check.
#   The old tools/Package-Release.ps1 is retired (throws "OBSOLETE" at the top, P27).
```

Dependencies: edk2, LvglPkg, VS2019. LvglPkg is the `LvglPkg/` directory of
https://github.com/MikeWuPing/UEFI_Tools (the new-generation source; the older
UEFI_LVGL repository stopped at its 0.1.6-era state) — clone UEFI_Tools and copy
that directory to the project root as `LvglPkg`.

## Board Porting

All features are verified in the QEMU closed loop; real-hardware bring-up follows the checklist in `docs/board-porting-guide.md` (MRC interleave tables, SMBus SPD, vendor whitelist, Ventoy real-stick testing, MSR #GP handling, etc.).
