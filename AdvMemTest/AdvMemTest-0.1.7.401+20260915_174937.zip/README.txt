AdvMemTest 0.1.7（Build 401）—— UEFI 内存压力测试工具（免费版）
=====================================================================
文件清单：
  binaries/advmemtest-free.efi          主程序（X64 UEFI 应用，单文件无依赖、无需授权文件）
  iso/AdvMemTest-boot-0.1.7.401+20260915_174937.iso
                                        **可启动光盘镜像**：写入 U 盘（Rufus / balenaEtcher /
                                        Ventoy 正常模式）或挂进虚拟机 / BMC 虚拟光驱，开机即
                                        进程序，不需要先有 UEFI Shell；**先关闭 Secure Boot**
                                        （程序未签名）。用法与注意事项见
                                        docs/manual/iso-boot-readme.txt
  docs/manual/advmemtest-free-user-guide.md / .docx
                                        免费版技术手册（完整功能与操作说明）
  docs/manual/advmemtest-quick-guide.md / .docx
                                        快速上手（五步跑起第一次测试）
  docs/manual/advmemtest-feature-tour.gif 与 docs/manual/images/
                                        界面演示动图与全部功能截图（25 张）
  README.txt                            本文件

运行：
  ISO 形态：写入 U 盘或挂虚拟光驱，开机从该设备启动（免 Shell，直进程序）。
  Shell 形态：把 advmemtest-free.efi 复制到 UEFI Shell 所在盘（通常 fs0:），
             Shell 提示符下输入文件名回车，或写入 startup.nsh 开机自启。
  起测：连按两下回车；运行中按 Esc 是暂停（再按继续），停止走“测试”菜单“停止测试”。

报告：停止 / 跑满指定轮数 / 退出三个时机自动写到 fs0:\advmemtest_report.html
      （ISO 只读介质写不出文件——串口给一行 Write Protected 告警，程序不崩）。

版本：0.1.7（Build 401）｜ APP_VERSION = v0.1.7.free.401
SHA256 (binaries/advmemtest-free.efi) : 86FFE7A07EC23EDBC9A9889ED3740D8384CE77F5FB4BF17A9EB4262C67DBA237
SHA256 (AdvMemTest-boot-0.1.7.401+20260915_174937.iso) : B5C361EAC88A54D05DB98C77751F7BEE67087436F4DF5718DAAB7C4BE83C2F5E

许可：个人用户免费使用；商业用途（营利性部署 / 分发 / 预装）需提前联系作者书面授权
      （商业路径 = AdvMemTest 专业版授权）。详见套件根 README 的许可节。
