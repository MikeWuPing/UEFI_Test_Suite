# AdvMemTest 0.1.7（Build 810）— UEFI 内存压力测试工具（免费版）

本包为 **AdvMemTest 免费版**的免 Shell 可启动镜像与使用手册，个人用户免费使用。
程序本体位于 `binaries/advmemtest-free.efi`，可启动镜像位于 `iso/`，完整使用说明见
`README.txt` 与 `docs/manual/advmemtest-free-user-guide.md`。

- 版本：`v0.1.7.free.810`
- 适用：x64 UEFI；使用前请关闭 Secure Boot
- 许可：个人用户免费使用；商业用途需联系作者取得授权
- 专业版不在本包内；商业授权路径请联系作者
