# Secure Boot 签名指南（FB-16）

本指南面向发布/交付工程师：把 `AdvMemTestFree.efi`、`AdvMemTestPro.efi`（以及 ISO/PXE 启动链里的 `BOOTX64.EFI`）签成可被开启 Secure Boot 的固件接受的可执行文件。

**边界先说清**：签名只解决“固件是否允许加载这个 PE”。它**不改变** Pro 授权（`ADVMTEST.LIC`/`site.lic` 另有一套 RSA 验签）、**不保护** `ADVMTEST.CFG`/`site.cfg` 的内容、**不防止**拷贝或逆向，也**不能绕过**目标固件的 DB/KEK 策略。私钥与 PFX 口令一旦泄漏，攻击者可以签出被该信任链接受的任意 EFI——保管等级按发布密钥对待。

## 1. 工具与前置条件

- Windows 10/11 + PowerShell 5.1。
- Windows SDK 的 `signtool.exe`（本机实测 `C:\Program Files (x86)\Windows Kits\10\bin\10.0.22621.0\x64\signtool.exe`；脚本会自动找最高版本）。
- 已构建的产物：`dist\AdvMemTestFree\advmemtest_free.efi`、`dist\AdvMemTestPro\advmemtest_pro.efi`（或打包后的 ISO/PXE 目录）。
- 三个脚本在 `tools/`：
  - `New-SigningKey.ps1`：生成自签代码签名证书（RSA，默认 3072 位；SHA-256；EKU Code Signing；DigitalSignature），导出 PFX + CER。
  - `Sign-AdvMemTest.ps1`：签名 + `signtool verify /pa /v` 验证；支持 `-VerifyOnly`、RFC3161 时间戳、多文件（逗号分隔或通配）。
  - `Test-SecureBootSigning.ps1`：临时密钥自检（签副本、篡改检测、错误证书检测、`-Force` 事务故障注入、清理），不碰正式产物。

**口令用法（重要）**：

- **推荐**省略 `-Password`，两个脚本会 `Read-Host -AsSecureString` 交互提示，不回显：
  ```powershell
  powershell -ExecutionPolicy Bypass -File tools\New-SigningKey.ps1 -OutDir D:\secure\advmemtest-signing
  powershell -ExecutionPolicy Bypass -File tools\Sign-AdvMemTest.ps1 `
    -File D:\secure\staging\advmemtest_free.signed.efi `
    -Pfx D:\secure\advmemtest-signing\AdvMemTest-signing.pfx
  ```
- **不要**写 `-Password (Read-Host -AsSecureString)`：它会被字符串化成字面量 `System.Security.SecureString`，脚本会报错拒绝。
- 仅自动化场景可传明文 `-Password '...'`；明文会进入 PowerShell 命令历史（PSReadLine）与本机进程命令行（本机管理员可见）。`signtool` 自身只接受 `/p` 明文口令，这是工具限制。量产建议企业 PKI + HSM/EV 令牌。

**密钥长度**：`New-SigningKey.ps1 -KeyLength 2048|3072|4096`（默认 3072）。**RSA-2048 + SHA-256 是固件兼容性基线**，不确定目标固件能力时优先 2048；3072/4096 只在对目标机型验证通过后使用（老固件的 RSA/PKCS#1 实现可能不支持大于 2048 的密钥）。签名后在**目标机**做一次加载实测，不能只以签名机 `signtool` 成功为准。

## 2. 三条信任路线

### 路线 A：自签 CA + 目标固件 DB 注册（测试/受控机队）

1. **生成密钥（一次，私钥离线保管）**：
   ```powershell
   powershell -ExecutionPolicy Bypass -File tools\New-SigningKey.ps1 `
     -OutDir D:\secure\advmemtest-signing -KeyLength 2048
   ```
   产出 `AdvMemTest-signing.pfx`（含私钥，**绝不入库/外发**）与 `AdvMemTest-signing.cer`（公钥证书）。记下输出的 Thumbprint 与到期日。
2. **准备 staging 副本并签名**（示例省略 `-Password`，运行时交互输入；自动化才传明文并注意历史/argv）：
   ```powershell
   New-Item -ItemType Directory -Force D:\secure\staging
   Copy-Item dist\AdvMemTestFree\advmemtest_free.efi D:\secure\staging\advmemtest_free.signed.efi
   Copy-Item dist\AdvMemTestPro\advmemtest_pro.efi    D:\secure\staging\advmemtest_pro.signed.efi
   powershell -ExecutionPolicy Bypass -File tools\Sign-AdvMemTest.ps1 `
     -File D:\secure\staging\advmemtest_free.signed.efi,D:\secure\staging\advmemtest_pro.signed.efi `
     -Pfx D:\secure\advmemtest-signing\AdvMemTest-signing.pfx `
     -TimestampUrl http://timestamp.digicert.com
   ```
   每个文件应输出 `VERIFIED`；任一步失败脚本非零退出。自签根不在 Windows 根库时 `/pa` 会报根不受信，见第 4 节。
   **签名副本必须回填 dist**：`New-BootIso.ps1` 读取 `dist\AdvMemTest<Sku>\advmemtest_<sku>.efi`。验证通过后，把
   `D:\secure\staging\advmemtest_free.signed.efi` / `..._pro.signed.efi` 复制回对应的 dist 路径；
   若选择原地签 dist，先把 dist 复制成 `D:\secure\staging\advmemtest_free.unsigned.efi`（Pro 同理）保留未签名备份。
   **不回填就打包，ISO/PXE 里仍是未签名字节。**
3. **先备份 PK/KEK/db/dbx，再注册 CER**：
   - 固件 UI 的 Key Management 通常支持导出 PK/KEK/db/dbx；Linux 可用
     `efi-readvar -v PK -o PK.bin`、`-v KEK -o KEK.bin`、`-v db -o db.bin`、`-v dbx -o dbx.bin`；
     `sbctl export-enrolled-keys --dir sb-backup --format esl` 可导出 PK/KEK/db（dbx 另行备份）。
   - 把备份放到离线介质。改错 DB/PK 可能让机器无法启动；**不要在没有备份的情况下清 PK**。
4. **进入可写状态（二选一）**：
   - **Setup Mode**：在固件 UI 清 PK（需要当前 PK 授权）→ 重启；固件进入 Setup Mode，此时允许直接更新 db/KEK/PK。**Setup Mode 下固件不校验签名**，不能拿这段时间的启动成功当“签名生效”证据。
   - **不进入 Setup Mode（保持 User Mode）的 KEK 授权更新**：若持有当前 KEK 私钥，可
     `efi-updatevar -a -c AdvMemTest-signing.cer -k KEK.key db`，直接向 db 追加证书。
     这条路径**不需要清 PK、不会让固件进入 Setup Mode**：db 更新包由 KEK 签名，PK 保持启用。
5. **注册 CER 到 db**（CER 是公钥证书，不是 PFX）：
   - 固件 UI：Security → Secure Boot → Key Management → DB → Enroll/Append，选择 FAT 盘根目录的 CER。
   - Setup Mode 下：`efi-updatevar -a -c AdvMemTest-signing.cer db`（无 `-k` 时直接更新）。
   - Linux `sbctl`（**不要**用裸 `sbctl enroll-keys` 期待它注册我们的 CER）：
     ```bash
     sudo mkdir -p /var/lib/sbctl/keys/custom/db
     sudo cp AdvMemTest-signing.cer /var/lib/sbctl/keys/custom/db/
     sudo sbctl enroll-keys -c -m
     ```
     `-c` 才会把 sbctl 自定义目录里的 db/KEK 证书一起写入；`-m` 保留 Microsoft 证书（否则可能丢掉微软信任链）。`sbctl enroll-keys` 会写 PK/KEK/db，通常要求固件处于 Setup Mode（先按上一步备份并清 PK）；旧版 sbctl 的 keydir 是 `/usr/share/secureboot/keys/`，对应目录为 `/usr/share/secureboot/keys/custom/db/`。`sbctl` 还会写入它自己生成的 PK/KEK/db 密钥；执行前先备份，执行后用 `sbctl status` 核对。
   - Windows：`Set-SecureBootUEFI` / OEM KeyTool（按平台文档，需已签名的更新包）。
6. **退出 Setup Mode 并确认强制生效**：
   - 注册/恢复 PK（以及所需 KEK），重启；`sbctl status` 应显示 `Setup Mode: Disabled`、`Secure Boot: Enabled`；Windows `Confirm-SecureBootUEFI` 返回 True，Linux `mokutil --sb-state` 显示 enabled。
   - **强制验证**：在 `Setup Mode: Disabled` 且 `Secure Boot: Enabled` 下，未签名 EFI 必须被固件拒绝/不出现启动项，签名 EFI 必须能加载。若仍在 Setup Mode，启动成功不能证明签名被校验。
7. **回滚**：重新进入 Setup Mode，删除自定义 db 条目或恢复更新前的 PK/KEK/db/dbx 备份；重启并确认 Secure Boot 恢复。保留备份直到机队稳定。

> 自签证书默认不在 Windows 根证书库，`signtool verify /pa` 在**签名机**上会报根不受信。自检脚本对此有 `-AllowUntrustedRoot` 模式（仍校验哈希、有效期与签名者，仅豁免根信任），并在输出 `STRICT-VERIFY SKIPPED`。要得到严格 `/pa` 的成功证据，需把 CER 装进签名机根库（会弹系统确认）或使用企业 PKI 证书。**发布验收不能拿 `-AllowUntrustedRoot` 冒充严格验证。**

### 路线 B：企业 PKI（推荐量产）

由企业 CA 签发带 Code Signing EKU 的证书（PFX 或 HSM/EV 令牌）。用 `Sign-AdvMemTest.ps1 -Pfx ...` 签名；若用 EV 硬件令牌，`signtool` 需改为 `/sha1 <thumbprint> /csp "<CSP>" /kc "<key container>"`（脚本不封装硬件令牌，按厂商文档执行）。

**关键口径：固件只信任它自己 db 里的证书。** 企业域控/AD、Windows 根证书库、Authenticode 时间戳信任都**不等于** Secure Boot 信任。要让企业证书签的镜像在目标机启动，必须满足其一：

- 把企业代码签名 CA（或完整的受信链）注册进**每台目标机**的 Secure Boot `db`（通过 PK/KEK 授权或 Setup Mode，步骤同路线 A 的备份/更新/回滚）；
- 或让镜像由 Microsoft UEFI CA 签名（见路线 C），利用固件内置的 Microsoft 信任。

没有 db 分发/注册步骤，“企业 PKI 签名”只会让 Windows 认为签名有效，Secure Boot 仍会拒绝加载。

### 路线 C：微软 UEFI CA（公开发布）

面向通用分发、希望免逐台注册直接被主流固件接受时，按微软 UEFI 签名流程提交（EV 代码签名证书 + 微软 UEFI CA 审核）。周期与费用按微软政策；通过后由微软签名，**不要**再用自签证书覆盖签名。

- 当前应使用 **Microsoft UEFI CA 2023**；**Microsoft UEFI CA 2011 已于 2026-06-27 到期**。
- 发布前**检查目标机固件的 db**（固件 UI/`efi-readvar -v db -o db.bin`/`sbctl list-enrolled-keys`）：确认其中包含 MS UEFI CA 2023，或仍保留 2011。老固件可能只信 2011，新固件可能只带 2023。
- 过渡期需要**双签**（同时带 2011 与 2023 CA 的签名，具体由微软签名服务/提交选项决定）；不要假设一份签名覆盖所有固件。对固件版本混杂的机队，先抽样验证再全面发布。
- 私有/受控机队不必走这条；路线 A/B 更可控。

## 3. 签哪些文件、ISO/PXE 的顺序

| 形态 | 需要签名的对象 | 备注 |
|---|---|---|
| UEFI Shell 直跑 | `advmemtest_free.efi` / `advmemtest_pro.efi` | 交付的 EFI 本体 |
| ISO 启动（UDF 树） | ISO 内 `/EFI/BOOT/BOOTX64.EFI` | 由**已签名**的 EFI 打包而来 |
| ISO 启动（El Torito ESP） | `ESP_IMG.BIN` 内的 `EFI/BOOT/BOOTX64.EFI` | 与 UDF 树是同一份签名字节，必须一起校验 |
| PXE 启动 | TFTP 根的 `BOOTX64.EFI`（即改名后的 EFI） | `site.lic`/`site.cfg` 的信任边界另见 PXE 指南，签名不保护它们 |

**ISO 正确顺序（不能签 ISO 容器）**：

1. 先保留未签名 staging 副本（见下节“原地签名风险”）；
2. 对 `dist\AdvMemTestFree\advmemtest_free.efi` / `dist\AdvMemTestPro\advmemtest_pro.efi` **先签名并验证**。推荐做法：把 dist 原件另存为 `*.unsigned.efi`，对 `*.signed.efi` 副本签名并验证，再把**已签名副本放回** New-BootIso 读取的 `dist\...efi` 路径；若直接原地签 dist，务必先做未签名备份；
3. 再运行 `tools\New-BootIso.ps1`。它读取 `dist\AdvMemTest<Sku>\advmemtest_<sku>.efi`，把**同一份已签名字节**放进 UDF 树 `/EFI/BOOT/BOOTX64.EFI`，并嵌入 `ESP_IMG.BIN` 的内层 `EFI/BOOT/BOOTX64.EFI`：
   ```powershell
   powershell -ExecutionPolicy Bypass -File tools\New-BootIso.ps1 -Sku Free
   ```
4. 用 `tools\verify-iso-payload.py` 校验**两份副本**（UDF 树 + ESP 内层）的版本与 md5 一致：
   ```powershell
   python tools\verify-iso-payload.py dist\advmemtest-free.iso `
     dist\AdvMemTestFree\expected_version.txt --sku Free --stage-dir Build\bootiso\free
   ```
   输出应包含 `payload md5: MATCH` 与 `ESP_IMG.BIN` 内层 `EFI/BOOT/BOOTX64.EFI` 的版本行；任一不一致即失败；
5. 最后计算 **ISO 文件**的 SHA-256 入库：
   ```powershell
   Get-FileHash dist\advmemtest-free.iso -Algorithm SHA256
   ```

签 ISO 文件本身**无效**：UEFI 固件校验的是 ISO 里被加载的 PE，不是光盘容器。若重新打包 ISO，必须从**已签名 EFI** 重新生成（签后重打包会丢失/错配签名）；不要拿旧 ISO 改内容。

**原地签名风险与推荐做法**：

- `Sign-AdvMemTest.ps1` 是**原地签名**且按文件顺序处理；多文件时若第 N 个失败，前 N-1 个**已经写入签名**。不要假设“失败=所有文件未动”。
- 推荐**签副本再发布**：保留未签名的 staging 原件（如
  `D:\secure\staging\advmemtest_free.unsigned.efi`），对副本签名并验证；全部通过后，再把签名副本放回 `dist\`/ISO staging。若必须原地签 `dist\`，先做好未签名备份，并逐个文件核对。
- ISO 构建前再确认 `dist\...efi` 是签名后的那份（可用 `Get-FileHash` 与签名后记录比对）。
- **verified bytes = shipped bytes**：EFI 签名后不得再构建/覆盖该 EFI；ISO 必须由已签名 EFI 打包，ISO 打包后不得再改内容；最终对 EFI 与 ISO 重新计算哈希入库。

**PXE**：把签名后的 EFI 改名为 `BOOTX64.EFI` 放到 TFTP 根，记录哈希；TFTP 根 ACL/写保护仍是信任边界（`site.cfg` 没有应用层签名）。签名不改变 PXE 取件逻辑。

## 4. 验证

```powershell
# 严格验证（证书链在签名机受信时）
signtool verify /pa /v dist\AdvMemTestFree\advmemtest_free.efi
```

自签证书默认不在 Windows 根库，严格 `/pa` 会报根不受信。发布验收的**严格 `/pa` 成功证据**只能来自：企业 PKI 证书，或把 CER 装入签名机根库后的受控环境（会弹系统确认）；这是**人工/企业验收项**，不能由无人值守自检替代。`-AllowUntrustedRoot` 只做完整性复核，不作为严格验证证据。

在目标机开启 Secure Boot 实测：确认 `Setup Mode: Disabled` 且 `Secure Boot: Enabled` 后再做加载测试；未签名 EFI 应被拒绝，签名 EFI 应能启动。串口 `APP_VERSION=v0.1.7.<sku>.<build>` 与 `expected_version.txt` 一致。ISO 还要按第 3 节校验 UDF 树与 ESP 内层两份副本。失败时依次检查：证书 EKU 是否为 Code Signing、DB 是否注册的是 CER、密钥长度是否被固件支持、时间戳是否有效、ISO/PXE 里是否是签名后的那份文件、固件是否仍处于 Setup Mode（Setup Mode 下不校验签名，量产前必须退出）。

## 5. 自检与回归

```powershell
powershell -ExecutionPolicy Bypass -File tools\Test-SecureBootSigning.ps1
```

预期输出 `SIGN-TEST PASS`。自检开始时把 `dist\...efi` 复制成临时**未签名基线快照**，未签名拒绝用例针对该快照而不是 dist 实时文件；若发布产物事先已被签名，会明确打印 `UNSIGNED-REJECT SKIPPED`，保证自检仍可重复运行，同时始终校验 dist 与基线的 SHA-256 未变。其余覆盖：临时证书签名副本通过（放宽根信任的完整性校验）、篡改副本返回 `HashMismatch` 被拒、错误 PFX 签名者不匹配被拒、严格 `/pa` 打印 `STRICT-VERIFY SKIPPED`、`New-SigningKey -Force` 事务故障注入不会新旧双失；临时证书与目录清理干净。自检不会改动 `dist/` 产物，也不会在仓库留下密钥。

## 6. 私钥与发布纪律

- PFX/口令/私钥容器与仓库、构建机镜像、聊天工具分离；生产签名建议在离线签名机或 HSM 完成。
- `.gitignore` 已覆盖 `signing/`、`*.pfx`、`*.cer`、`*.pvk`、`*.p12` 与 `.tmp/.bak`；仍应在提交前 `git status` 复核。CER 是公钥，可按需分发给注册方；PFX/私钥/口令绝不进入发布包。
- 删证书不会删除 CNG 私钥容器（`%APPDATA%\Microsoft\Crypto\Keys`）；测试机可接受，生产机按企业密钥卫生流程处理。
- 轮换：新证书重新签全部在售产物；先把新证书加入 db，再移除旧证书（先加后删，避免变砖）；保留 PK/KEK/db/dbx 备份直到过渡期结束。

## 7. 发布检查清单

- [ ] 构建产物已定版（构建号写入 `VERSION.txt`），此后不再重建；未签名 staging 副本已保留。
- [ ] Free/Pro EFI 已签名并验证；多文件失败时已核对哪些文件已被原地签名。
- [ ] 严格 `/pa` 证据已按人工/企业 PKI 口径取得（或明确记录本次仅完整性验证）。
- [ ] ISO：**先签 EFI** → `New-BootIso.ps1` → `verify-iso-payload.py` 确认 UDF 树 `/EFI/BOOT/BOOTX64.EFI` 与 `ESP_IMG.BIN` 内层 `EFI/BOOT/BOOTX64.EFI` 两份副本一致 → 最后算 ISO SHA-256。ISO 容器本身未签名；重打包从已签名 EFI 开始。
- [ ] PXE：签名后的 `BOOTX64.EFI` 已部署到 TFTP 根并记录哈希；ACL/写保护仍有效。
- [ ] 目标机 `Setup Mode: Disabled`、`Secure Boot: Enabled`；未签名镜像被拒、签名镜像可启动；记录机型/固件版本。
- [ ] PK/KEK/db/dbx 备份在位；回滚步骤已演练。
- [ ] 签名后 SHA-256 与发布清单一致；PFX/私钥/口令未进入仓库或发布包；本指南已随发布包分发。
