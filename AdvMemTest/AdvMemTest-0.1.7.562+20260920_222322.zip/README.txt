AdvMemTest 0.1.7（Build 562）—— UEFI 内存压力测试工具（免费版）
=====================================================================
文件清单：
  binaries/advmemtest-free.efi          主程序（X64 UEFI 应用，单文件无依赖、无需授权文件）
  iso/AdvMemTest-boot-0.1.7.562+20260920_222322.iso
                                        **可启动光盘镜像**：写入 U 盘（Rufus / balenaEtcher /
                                        Ventoy 正常模式）或挂进虚拟机 / BMC 虚拟光驱，开机即
                                        进程序，不需要先有 UEFI Shell；**先关闭 Secure Boot**
                                        （程序未签名）。用法与注意事项见
                                        docs/manual/iso-boot-readme.txt
  docs/manual/advmemtest-free-user-guide.md / .docx
                                        免费版技术手册（完整功能与操作说明）
  docs/manual/advmemtest-quick-guide.md / .docx
                                        快速上手（五步跑起第一次测试）
  docs/manual/advmemtest-feature-tour.gif 与 docs/manual/images/
                                        界面演示动图与手册引用的全部截图（34 张）
  README.txt                            本文件

内置测试 Pattern（本版真值）：
  测试注册表共 33 条。
  免费版界面可勾选 13 条（另有 2 条引擎自检参考条不计入用户可见集，实际可
  执行 15 条）；专业版目录可见 31 条、可执行 33 条。免费版中未授权的专业版
  专属条目灰显并带锁标，点击会给出提示。

运行：
  ISO 形态：写入 U 盘或挂虚拟光驱，开机从该设备启动（免 Shell，直进程序）。
  Shell 形态：把 advmemtest-free.efi 复制到 UEFI Shell 所在盘（通常 fs0:），
             Shell 提示符下输入文件名回车，或写入 startup.nsh 开机自启。
  起测：连按两下回车；运行中按 Esc 是暂停（再按继续），停止走“测试”菜单“停止测试”。

报告：停止 / 跑满指定轮数 / 退出三个时机自动写到 fs0:\advmemtest_report.html
      （ISO 只读介质写不出文件——串口给一行 Write Protected 告警，程序不崩）。

版本：0.1.7（Build 562）｜ APP_VERSION = v0.1.7.free.562
SHA256 (binaries/advmemtest-free.efi) : 12FAA37524800C64DC4F9D921B120E087C299375BBF5099DF48240C7DC3FCB59
SHA256 (iso/AdvMemTest-boot-0.1.7.562+20260920_222322.iso) : 0BC5724050ED0E7561EA077DD22196EBE55E7B2F86223BC3C22EEF5B9487F9DB

许可：个人用户免费使用；商业用途（营利性部署 / 分发 / 预装）需提前联系作者书面授权。
专业版经商务渠道交付——请联系作者获取 Pro 版授权（本包为免费版）。
